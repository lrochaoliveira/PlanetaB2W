package br.com.planet;

import java.io.IOException;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonArray;

import br.com.planet.model.Planet;
import br.com.planet.service.ArgumentSwitcherService;
import br.com.planet.service.PlanetService;

/**
 * PlanetController
 * 
 * @author Luciana OLiveira
 *
 */
@RestController
public class PlanetController {
	
	@Autowired
	private PlanetService service;
	
	final private String COMMAND = "films";
	
	// find all planets in the BD. 
	@RequestMapping(value = "/planet", method = RequestMethod.GET)
	public Iterable<Planet> get(){
		 
		Iterable<Planet> planets = service.findAll();
		
		return planets;
	}
	
	// find a planet by id.
	@RequestMapping(value = "/planet/{id}", method = RequestMethod.GET)
	public ResponseEntity<Planet> getById (@PathVariable(value = "id") long id) {
		
		Optional<Planet> planet = service.findById(id);
		
		if(planet.isPresent()) {
			Planet newPlanet = planet.get();
			ArgumentSwitcherService argumentSwitcherService = new ArgumentSwitcherService();
			JsonArray qtdFilms = argumentSwitcherService.switcher(COMMAND, newPlanet.getNome());
			newPlanet.setQtsFilmes(qtdFilms.size());
            return new ResponseEntity<Planet>(newPlanet, HttpStatus.OK);
		} else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
	}
	
	// find a planet by name.
	@RequestMapping(value = "/planet/{nome}", method = RequestMethod.GET)
	public ResponseEntity<Planet> getByName (@PathVariable(value = "nome") String nome) throws IOException {
		
		Optional<Planet> planet = service.findByName(nome);
		  
	    if(planet.isPresent()) {
			Planet newPlanet = planet.get();
			ArgumentSwitcherService argumentSwitcherService = new ArgumentSwitcherService();
			JsonArray qtdFilms = argumentSwitcherService.switcher(COMMAND, 
					newPlanet.getNome());
			newPlanet.setQtsFilmes(qtdFilms.size());
            return new ResponseEntity<Planet>(newPlanet, HttpStatus.OK);
	    } else {
	       return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	}

	@RequestMapping(value = "/planet/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Object> delete(@PathVariable(value = "id") long id){
		
		Optional<Planet> planet = service.findById(id);
				
        if(planet.isPresent()){
            service.delete(planet.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@RequestMapping(value = "/planet", method = RequestMethod.POST )
	public Planet save(@Valid @RequestBody Planet planet) {
		return service.save(planet);
		
	}
	
	@RequestMapping (value = "/planet/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Planet> update(@PathVariable (value = "id") long id, @Valid @RequestBody Planet newPlanet){
		
		Optional<Planet> oldPlanet = service.findById(id);
		
		if(oldPlanet.isPresent()){
			Planet planet = oldPlanet.get();
			planet.setNome(newPlanet.getNome());
			planet.setClima(newPlanet.getClima());
			planet.setTerreno(newPlanet.getTerreno());
			service.save(planet);
			return new ResponseEntity<Planet>(planet, HttpStatus.OK);
		} else {
			return new ResponseEntity<> (HttpStatus.NOT_FOUND);
		}
	}
			
}
