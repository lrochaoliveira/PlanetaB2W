package br.com.planet.service;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.planet.model.Planet;
import br.com.planet.repository.PlanetRepository;

/**
 * PlanetService
 * 
 * @author Luciana Oliveira
 *
 */

@Service
public class PlanetService {
	@Autowired
	private PlanetRepository _repository;
	
	public Iterable<Planet> findAll(){
		
		Iterable<Planet> planeta = _repository.findAll();
		
		return planeta;
		
	}
	
	public Optional<Planet> findById(long id){
		
		Optional<Planet> planeta = _repository.findById(id);
		
		return planeta;
        
	}
	
	public Optional<Planet> findByName(String nome) throws IOException{
		
		Optional<Planet> planeta = _repository.findByName(nome);
		
		return planeta;
		
	}
	
	
	public void delete(Planet planet) {
		
		_repository.delete(planet);
		
	}
	
	
	public Planet save(Planet planeta){
		
		return _repository.save(planeta);
		
	}
	
	

}
