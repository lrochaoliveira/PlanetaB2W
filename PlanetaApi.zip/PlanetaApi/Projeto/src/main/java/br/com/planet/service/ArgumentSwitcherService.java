package br.com.planet.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import br.com.planet.API;
import br.com.planet.Printer;
import br.com.planet.repository.GetRequestRepository;


public class ArgumentSwitcherService {

	private static final API apiCalls = new API();
    private GetRequestRepository repository = new GetRequestRepository(apiCalls);
    Printer printer = new Printer();

    public JsonArray switcher(String command, String searchquery) {

        JsonObject jsonObject;
        JsonArray defaultResults = new JsonArray();

        switch (command) {
            case "films":
                jsonObject = repository.getAll("films", searchquery);
                JsonArray filmresults = jsonObject.getAsJsonArray("results");
                printer.printDetailsFilms(filmresults);
                return filmresults;
            case "planets":
                jsonObject = repository.getAll("planets", searchquery);
                JsonArray planetresults = jsonObject.getAsJsonArray("results");
                printer.printDetailsPlanets(planetresults);
                return planetresults;
            case "starships":
                jsonObject = repository.getAll("starships", searchquery);
                JsonArray starshipresults = jsonObject.getAsJsonArray("results");
                printer.printDetailsStarships(starshipresults);
                return starshipresults;
            default:
                System.out.println(command + " is not a available command");
                return defaultResults;
        }
    }
}
