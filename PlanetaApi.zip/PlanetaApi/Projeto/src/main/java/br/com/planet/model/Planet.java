package br.com.planet.model;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;

/**
 * Planet
 * 
 * @author Luciana Oliveira
 * 
 */
@Document(collection = "planet")
@Getter
public class Planet {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	private String nome;
	
	private String clima;
	
	private String terreno;
	
	private int qtsFilmes;

	public Long getId() {
		return id;
	}

	
	public Planet() {
		super();
	}
		
	public Planet(String nome, String clima, String terreno) {
		super();
		this.nome = nome;
		this.clima = clima;
		this.terreno = terreno;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getClima() {
		return clima;
	}

	public void setClima(String clima) {
		this.clima = clima;
	}

	public String getTerreno() {
		return terreno;
	}

	public void setTerreno(String terreno) {
		this.terreno = terreno;
	}


	public void setQtsFilmes(int qtsFilmes) {
		this.qtsFilmes = qtsFilmes;
	}


	public int getQtsFilmes() {
		return qtsFilmes;
	}


}
